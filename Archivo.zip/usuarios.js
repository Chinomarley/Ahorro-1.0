
const USUARIOS = {
  "admin": { password: "admin123", esAdmin: true, nombre: "Administrador", historial: [] },
  "personal01": { password: "clave01", esAdmin: false, nombre: "Usuario 1", historial: [] },
  "personal02": { password: "clave02", esAdmin: false, nombre: "Usuario 2", historial: [] }
};
